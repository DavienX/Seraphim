﻿import xbmcaddon

MainBase = 'INSERT GITHUB HTTP ADDRESS TO MAIN FILE HERE'
addon = xbmcaddon.Addon('plugin.video.Davien')
